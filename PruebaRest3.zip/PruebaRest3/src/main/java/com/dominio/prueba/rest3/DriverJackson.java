package com.dominio.prueba.rest3;

import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;

public class DriverJackson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			try {
				
				ObjectMapper mapper= new ObjectMapper();
				
				Persona persona = mapper.readValue(new File("data/datos_persona.json"),Persona.class);
				
				
				//LEER JACKSON Y CONVERTIRLO EN POJO
				System.out.println("id del usuario " + persona.getId());
				System.out.println("nombre del usuario " + persona.getNombre());
				System.out.println("apellido del usuario " + persona.getApellido());
				//System.out.println("USUARIO ACTIVO : " + (persona.isActivo()? "si":"no"));    //usamos el boolean ternario para que si esta activo nos diga si y si pone false nos pondra no 
				System.out.println("dni del usuario " + persona.getDni());
				
				
				
				//en lugar de usar el ternario del boolean usamos un if else
				if(persona.isActivo()) {
					
					System.out.println("usuario activo");
					
				}else {
					System.out.println("usuario pasivo");
				}
				
				//mostramos idiomas con un for y le quitamos ln al println 
				for(String idiomas: persona.getIdiomas() ) {
					
					System.out.print(idiomas+",");
					
				}
				
				//mostramos los idiomas con un for de diferente manera 
				
				String [] idiomas = persona.getIdiomas();
				for (int i=0 ; i<idiomas.length ; i++) {
					System.out.println(idiomas[i]);
					
					
				}
				//tras modificar datos_persona.json  lo invocamos aqui en el archivo driver
				Datosregistro datosregistro = persona.getDatosregistro();
				//hacemos un for de los idiomas numerados
				for (int i=0 ; i<idiomas.length ; i++) {
				System.out.println("idioma"+(i+1)+ ":"+idiomas[i]);
				}
				
				//mostramos por pantalla los datos del registro trasladandolo con el get
				System.out.println("DATOS DE REGISTRO");
				System.out.println("Domicilio del usuario : "+datosregistro.getDomicilio());
				System.out.println("ciudad del usuario : "+datosregistro.getCiudad());
				System.out.println("codigo postal del usuario : "+datosregistro.getCodigo_postal());
				System.out.println("pais del usuario : "+datosregistro.getPais());
				System.out.println("FECHA DE ALTA del usuario : "+datosregistro.getFecha_alta());
				
				
				
				
			}catch(Exception e){
				e.printStackTrace();
			}
			
		
	
	}
}

