package com.dominio.prueba.rest3;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

//@JsonIgnoreProperties(ignoreUnknown = true)

public class Persona {
		//PROPIEDADES DE LA CLASE PERSONA
	private int id;
	private String nombre;
	private String apellido;
	private boolean activo;
	private String dni;
	private String idiomas[];
	private Datosregistro datosregistro;
	
	//getters y setters
	
	public int getId() {
		return id;
	}
	public String[] getIdiomas() {
		return idiomas;
	}
	public void setIdiomas(String[] idiomas) {
		this.idiomas = idiomas;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public boolean isActivo() {
		return activo;
	}
	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public Datosregistro getDatosregistro() {
		return datosregistro;
	}
	public void setDatosregistro(Datosregistro datosregistro) {
		this.datosregistro = datosregistro;
	}
	
	
	
	
	
	
	

	 
	
	
}
