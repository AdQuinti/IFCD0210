package com.dominio.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;

public class DriverJackson {

	public static void main(String[] args) {

		// hacemos la conversion de JSON a JAVA
		try { 
			// creamos objeto ObjectMapper - coge los datos de un archivo JSON
			ObjectMapper mapper = new ObjectMapper();
			
			//lwwmoa con otro objeto de la class Persona e indicamos dnd esta archivo JSON)
			Persona persona = mapper.readValue(new File("data/datos_persona.json"), Persona.class);
			
			// leer jackson y convertirlo en POJO
			System.out.println("Nombre de persona: "+persona.getNombre()); // imprime solo nombre
			System.out.println("Apellido de persona: "+persona.getApellido());
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
