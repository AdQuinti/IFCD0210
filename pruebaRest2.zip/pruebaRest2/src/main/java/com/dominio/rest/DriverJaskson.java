package com.dominio.rest;

import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;

public class DriverJaskson {

	public static void main(String[] args) {
		// hacemos la conversion de JSON a JAVA
		try {
			// creamos objeto ObjectMapper - coge los datos de un archivo JSON
			ObjectMapper mapper = new ObjectMapper();

			// lwwmoa con otro objeto de la class Persona e indicamos dnd esta archivo JSON)
			Persona persona = mapper.readValue(new File("data/datos_persona.json"), Persona.class);

			// leer jackson y convertirlo en POJO
			System.out.println("Id de persona: " + persona.getId()); 
			System.out.println("Nombre de persona: " + persona.getNombre()); // imprime solo nombre
			System.out.println("Apellido de persona: " + persona.getApellido());
			System.out.println("DNI: " + persona.getDni());
			System.out.println("Usuario activo: " +(persona.isActivo()?"Si":"No"));
	// Mostrar los idiomas
            System.out.print("Idiomas:");
            /*for (String idioma : persona.getIdiomas()) {
                System.out.print(idioma+", ");
            }*/
            String [] idiomas = persona.getIdiomas(); // otra forma de hacer for
            for (int i=0;i<idiomas.length;i++) {
            	System.out.print(idiomas[i]);
            	System.out.print(", ");
            }

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
